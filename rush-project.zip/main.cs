using System;

class Program
{
    static void Main()
    {
        string[] palavras = {  "Aventureiro", "Belezamaior", "CantoriaFina", "DançaFrenesi", "EstrelaBrilha", "FutebolShow", "GargalhadaTop", "Historiador", "InvernoFrio", "Janelapequena",
"Laranjadoce", "MacacoLouco", "NoiteEstrelada", "OuvirMúsicas", "PalavraMágica", "Queijodelícia", "RisoContagiante", "SorrirFeliz", "Trabalhador", "UvaMadura",
"Ventogelado", "XícaradeChá", "ZebraListrada", "Amorpuro", "Brincadeira", "CachorroFiel", "Docemel", "EscoladeArtes", "Felicidades", "Girafalinda",
"HeróiDestemido", "ÍndioCorajoso", "JardimFloral", "LâmpadaAcesa", "MeiaColorida", "NuvemBranca", "Ondasonora", "Pássarocantante", "Queimarossos", "RiquezaAbundante",
"SorveteCremoso", "TênisConforto", "Uísquedestilado", "Vídeodivertido", "XaropedeTosse", "ZangadoMuito", "Alegriafesta", "Bicicletaveloz", "CanetaEsferográfica",
"Desejorealizado", "Escadavoadora", "Festajubilante", "Girinoinquieto", "Históriareal", "Irmãoquerido", "JantarSaboroso", "Lápiscriativo", "Maçãsuave", "Navegarlivremente",
"Ouviratentamente", "Pãogostoso", "Quenteapaixonado", "Rodaveloz", "Solbrilhante", "Tatuagemsimbólica", "Uvafresca", "Voomágico", "Xalequentinho", "Zangãoperseverante",
"Amigocarinhoso", "Bebidacolorida", "Coelhocurioso", "Dentebonito", "EstrelaBrilhante", "Fadaencantadora", "Gritofeliz", "Horaboa", "Ilhadeserta", "Jovemalegre",
"Lixoreciclado", "Mãecoruja", "Noiteestrelada", "Ônibuslotado", "Papelpintado", "Quartopequeno", "Ratotranquilo", "Saposaltitante", "Tempoameno", "Ursocarinhoso",
"Vacasalgada", "Xalelilás", "Zangadodesafiador", "Amigofiel", "Boladefutebol", "Caminharapido", "Docemelancia", "Espadasamurai", "Fogobrilhante", "Gatofofo",
"Horáriosincronizado"

 };

        Random random = new Random();

        Console.WriteLine("Digite quantas palavras você deseja gerar:");
        int qnt = int.Parse(Console.ReadLine());

        for (int i = 0; i < qnt; i++)
        {
            int indiceAleatorio = random.Next(0, palavras.Length);
            string palavraAleatoria = palavras[indiceAleatorio];

            Console.WriteLine(palavraAleatoria);
        }
    }
}







